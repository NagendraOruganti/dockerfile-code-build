# LoginApp

# Only for .NET app, at app container
        {
            "name": "CORECLR_PROFILER_PATH",
            "value": "/opt/datadog/Datadog.Trace.ClrProfiler.Native.so"
        }
